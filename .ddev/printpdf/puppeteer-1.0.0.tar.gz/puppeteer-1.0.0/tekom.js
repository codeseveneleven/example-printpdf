'use strict';

let nodeArguments = process.argv;
const puppeteerPath = nodeArguments[2];
const url = nodeArguments[3];
const pdfPathAndFileName = nodeArguments[4];
const format = nodeArguments[5];

const puppeteer = require(puppeteerPath);
let browser, page, options;

const today  = new Date();

// if language is english
if (url.indexOf("L=1") > -1) {
    const date = today.toLocaleDateString("en-US", { year: 'numeric', month: '2-digit', day: '2-digit' });
    options = {
        path: pdfPathAndFileName
        , format: format
        , printBackground: true
        , margin: { top: "60px", right: "0", bottom: "100px", left: "0" }
        , displayHeaderFooter: true
        , headerTemplate: `
        <div style="font-size: 8pt; width: 100%;">
          <span style="float: left; margin-left: 60px;"></span><span style="float:right; margin-right: 60px;">` + date + `</span>
        </div>
      `
        , footerTemplate: `
        <div style="font-size: 8pt; width: 100%;">
          <span style="float: left; margin-left: 60px;">tcworld GmbH</span><span style="float:right; margin-right: 60px;">Page <span class="pageNumber"></span><span> of </span><span class="totalPages"></span></span>
        </div>
      `,
    };
} else {
    const date = today.toLocaleDateString("de-DE", { year: 'numeric', month: '2-digit', day: '2-digit' });
    options = {
        path: pdfPathAndFileName
        , format: format
        , printBackground: true
        , margin: { top: "60px", right: "0", bottom: "100px", left: "0" }
        , displayHeaderFooter: true
        , headerTemplate: `
            <div style="font-size: 8pt; width: 100%;">
              <span style="float: left; margin-left: 60px;"></span><span style="float:right; margin-right: 60px;">` + date + `</span>
            </div>
          `
        , footerTemplate: `
            <div style="font-size: 8pt; width: 100%;">
              <span style="float: left; margin-left: 60px;">tcworld GmbH</span><span style="float:right; margin-right: 60px;">Seite <span class="pageNumber"></span><span> von </span><span class="totalPages"></span></span>
            </div>
          `,
    };
}


(async () => {
    browser = await puppeteer.launch({
        args: ['--no-sandbox', '--disable-setuid-sandbox']
        , headless: true // print to pdf only works in headless mode currently
    });
    page = await browser.newPage();

    // this section can loop for processing of multiple files if needed.
    await page.goto(url, { waitUntil: 'networkidle2' });

    await page.pdf(options);

    await browser.close();
})();
