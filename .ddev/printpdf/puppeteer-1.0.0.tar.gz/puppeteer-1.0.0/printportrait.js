'use strict';

let nodeArguments = process.argv;
const puppeteerPath = nodeArguments[2];
const url = nodeArguments[3];
const pdfPathAndFileName = nodeArguments[4];
const format = nodeArguments[5];

const puppeteer = require(puppeteerPath);
let browser, page, options;

// if format has width and height (e.g. 158mm*224mm)
if (format.includes('*')) {
    const sizes = format.split('*');
    const width = sizes[0];
    const height = sizes[1];

    options = {
        path: pdfPathAndFileName
        , width: width
        , height: height
        , printBackground: true
        , margin: { top: "0", right: "0", bottom: "0", left: "0" }
        , pageRanges: '1'
    };
} else {
    options = {
        path: pdfPathAndFileName
        , format: format
        , printBackground: true
        , landscape: false
        , margin: { top: "0", right: "0", bottom: "0", left: "0" }
        , pageRanges: '1'
    };
}

(async () => {
    browser = await puppeteer.launch({
        args: ['--no-sandbox', '--disable-setuid-sandbox']
        , headless: true // print to pdf only works in headless mode currently
    });
    page = await browser.newPage();

    // this section can loop for processing of multiple files if needed.
    await page.goto(url, { waitUntil: 'networkidle2' });
    await page.pdf(options);

    await browser.close();
})();
