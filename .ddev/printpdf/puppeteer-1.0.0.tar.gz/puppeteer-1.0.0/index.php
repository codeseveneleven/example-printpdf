<?php
$headers = getallheaders();
if (!isset($headers['X-Api-Authorization']) || $headers['X-Api-Authorization']!=='d7U-Jq--NMYt33uYELMuJ_') {
	header('HTTP/1.1 403 Forbidden');
	die();
}


$url = $_GET['url'];
$format = $_GET['format'];
$fileName = $_GET['filename'] ?? 'printpdf.js';
if (empty($url)) {
	die('no url given');
}
if (empty($format)) {
	die('no format given');
}
$out = tempnam(sys_get_temp_dir(),'pdfprint');
$cmd = '/usr/local/bin/node '.__DIR__. '/' . $fileName .' '.__DIR__.'/node_modules/puppeteer "'.urldecode($url).'" "'.$out.'"  "'.urldecode($format).'" 2>&1';

$log = [$_REQUEST,$cmd];
exec($cmd,$log);

$buf = file_get_contents($out);
unlink($out);

file_put_contents( __DIR__.'/log.txt', json_encode($log),FILE_APPEND);

header('Content-Type: application/pdf');
print $buf;

//print_r([$headers,$out,$cmd,$log]);

exit;
